﻿#include<iostream>
#include<string>
#include<time.h>
#include<fstream>
#include<conio.h>
#include<Windows.h>
#include<list>
#include<vector>
#include<algorithm>
#include<iterator>
using namespace std;

//игра бомберман
#define ESC     27//ESC
#define ENTER   13//ENTER
#define SPACE   32//SPACE
#define UP      72//UP
#define DOWN    80//DOWN
#define LEFT    75//LEFT
#define RIGHT   77//RIGHT
#define CURSOR1  0//CURSOR1
#define CURSOR2 224//CURSOR2
// функция для смена цвета
void SetColor(WORD wAttributes)
{
	HANDLE hOUTPUT = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hOUTPUT, wAttributes);
}

// функция для установки позиции каретки по координатам
void SetPos(int x, int y)
{
	COORD cd;
	cd.X = x;
	cd.Y = y;
	SetConsoleCursorPosition(
		GetStdHandle(STD_OUTPUT_HANDLE), cd);
}


enum mmenu { Start, Info, Exit };//енам меню созданный для переходов между пунктов в меню
enum vlvl { lvl1, lvl2, lvl3, lvl4, lvl5 };//енам лвл созданный для переходов между лвл

class coordinates {//класс Координаты
private:
	int x;//x - несет в себе информацию оси x
	int y;//y - несет в себе информацию оси y
public:
	//Аксессоры к классу Координаты
	int get_x()const { return x; }
	int get_y()const { return y; }
	void set_x(int X) { x = X; }
	void set_y(int Y) { y = Y; }

	virtual bool IsIntersept(int x, int y) {
		if (this->x == x && this->y == y) {
			return true;
		}
		else false;
	}
	virtual bool IsIntersept(const coordinates& obj) {
		return IsIntersept(obj.get_x(), obj.get_y());
	}
	void minus_x_player() {
		x -= 3;
	}//уменьшение оси x на 3
	void plus_x_player() {
		x += 3;
	}//увеличение оси X на 3
	void minus_y_player() {
		y -= 3;
	}//уменьшение оси y на 3
	void plus_y_player() {
		y += 3;
	}//увеличение оси y на 3
};

class proverka_na_storony {//класс Проверка на сторону
private:
	bool Up;//up - несет в себе проверку на шаг в верх
	bool Down;//down - несет в себе проверку на шаг в низ
	bool Left;//left - несет в себе проверку на шаг в лево
	bool Right;//right - несет в себе проверку на шаг в право
public:
	//Аксесоры к классу Проверка на сторону
	bool get_Up()const { return Up; }
	bool get_Down()const { return Down; }
	bool get_Left()const { return Left; }
	bool get_Right()const { return Right; }

	void set_Up(bool u) { Up = u; }
	void set_Down(bool d) { Down = d; }
	void set_Left(bool l) { Left = l; }
	void set_Right(bool r) { Right = r; }

};

//класс игрока
class player :public proverka_na_storony, public coordinates {//класс игрок наследует классы координаты и проверку на стороны
private:

public:
	player() {}//конструктор, с наследованиями который принимает аргументы 

	//функция для проверки в какую сторону сможет пойти игрок
	void Proverka(char** Pole, int x, int y) {
		if (Pole[x - 2][y] == ' ') { set_Up(true); }
		else { set_Up(false); }
		if (Pole[x][y - 2] == ' ') { set_Left(true); }
		else { set_Left(false); }
		if (Pole[x][y + 2] == ' ') { set_Right(true); }
		else { set_Right(false); }
		if (Pole[x + 2][y] == ' ') { set_Down(true); }
		else { set_Down(false); }
	}


	//функция убирает символы после перемещения
	void podtcithenie(char** Pole, int x, int y) {
		if (Pole[x - 1][y] != '8') {
			Pole[x - 1][y] = ' ';
			Pole[x][y - 1] = ' '; Pole[x][y] = ' '; Pole[x][y + 1] = ' ';
			Pole[x + 1][y] = ' ';
			SetPos(y, x - 1); cout << " ";
			SetPos(y - 1, x); cout << "   ";
			SetPos(y, x + 1); cout << " ";
		}
	}
	//метод рисует игрока
	void risovayie_player(int y, int x) {
		SetPos(x, y - 1); cout << "@";
		SetPos(x - 1, y); cout << "/" << char(219) << "\\";
		SetPos(x, y + 1); cout << char(186);
	}
	//функция заполняет поле игроком
	void Draw(char** Pole, int i, int j) {
		/*Pole[i - 1][j - 1] = ' ';*/ Pole[i - 1][j] = '@'; /*Pole[i - 1][j + 1] = ' ';*/
		Pole[i][j - 1] = '/'; Pole[i][j] = '1'; Pole[i][j + 1] = '\\';
		/*Pole[i + 1][j - 1] = ' ';*/ Pole[i + 1][j] = '2'; /*Pole[i + 1][j + 1] = ' ';*/
	}

};


class Mob :public coordinates, public proverka_na_storony {//класс моб наследует класс координаты и проверки на стороны
private:
public:
	//функция прорисовка моба вместе его перемещением
	void Draw_e(char** Pole, int i, int j, int lf = 0, int rg = 0) {
		Pole[i - 1 + lf][j - 1 + rg] = ' '; Pole[i - 1 + lf][j + rg] = '3'; Pole[i - 1 + lf][j + 1 + rg] = ' ';
		Pole[i + lf][j - 1 + rg] = '<'; Pole[i + lf][j + rg] = 'O'; Pole[i + lf][j + 1 + rg] = '>';
		Pole[i + 1 + lf][j - 1 + rg] = ' '; Pole[i + 1 + lf][j + rg] = '4'; Pole[i + 1 + lf][j + 1 + rg] = ' ';
		SetPos(j - 1 + rg, i + 1 + lf); cout << " " << char(210) << " ";
		SetPos(j - 1 + rg, i + lf); cout << "<O>";
		SetPos(j - 1 + rg, i - 1 + lf); cout << " " << char(244) << " ";
		set_x(i + lf); set_y(j + rg);
	}

	//функция удаление лишних эллементов экрана за мобами
	void podtcithenie_mob(char** Pole, int i, int j) {
		Pole[i - 1][j - 1] = ' '; Pole[i - 1][j] = ' '; Pole[i - 1][j + 1] = ' ';
		Pole[i][j - 1] = ' '; Pole[i][j] = ' '; Pole[i][j + 1] = ' ';
		Pole[i + 1][j - 1] = ' '; Pole[i + 1][j] = ' '; Pole[i + 1][j + 1] = ' ';
		SetPos(j - 1, i + 1); cout << "   ";
		SetPos(j - 1, i); cout << "   ";
		SetPos(j - 1, i - 1); cout << "   ";
	}
	//функция проверки мобов на дальнейшее перемещение либо лишение жизни игрока
	void Proverka(char** Pole, int i, int j) {
		if (Pole[i - 2][j] == ' ' || Pole[i - 2][j] == '2') {
			set_Up(true);
		}
		else { set_Up(false); }
		if (Pole[i + 2][j] == ' ' || Pole[i + 2][j] == '@') {
			set_Down(true);
		}
		else { set_Down(false); }
		if (Pole[i][j - 2] == ' ' || Pole[i][j - 2] == '\\') {
			set_Left(true);
		}
		else { set_Left(false); }
		if (Pole[i][j + 2] == ' ' || Pole[i][j + 2] == '/') {
			set_Right(true);
		}
		else { set_Right(false); }
	}



};






class Bomb :public coordinates, public proverka_na_storony {//класс bomb наследует координаты и проверку на стороны
private:
	bool bomb;//присутсвует ли бомба на карте
	int vz;//время жизни бомбы
public:
	Bomb() :vz(1), bomb() {}//Конструктор бомбы

	//Акссесоры класса бомба
	bool get_bomb()const { return bomb; }
	int get_vz()const { return vz; }
	void set_vz(int VZ) { vz = VZ; }
	void set_bomb(bool BOMB) { bomb = BOMB; }
	//функция уменьшение времени жизни бомбы на 1
	void vz_minus_minus() {
		vz--;
	}

	//функция удаляющая лишние эллементы за бомбой с проверкой верх вниз
	void optimization_podtcithenie_bomb_Up_Down(char** Pole, int x, int y, int ot = 0) {
		Pole[x - 1 + ot][y - 1] = ' '; Pole[x - 1 + ot][y] = ' '; Pole[x - 1 + ot][y + 1] = ' ';
		Pole[x + ot][y - 1] = ' '; Pole[x + ot][y] = ' '; Pole[x + ot][y + 1] = ' ';
		Pole[x + 1 + ot][y - 1] = ' '; Pole[x + 1 + ot][y] = ' '; Pole[x + 1 + ot][y + 1] = ' ';
		SetPos(y - 1, x + 1 + ot); cout << "   ";
		SetPos(y - 1, x + ot); cout << "   ";
		SetPos(y - 1, x - 1 + ot); cout << "   ";
	}
	//функция удаляющая лишние эллементы за бомбой с проверкой лево право
	void optimization_podtcithenie_bomb_Left_Right(char** Pole, int x, int y, int ot = 0) {
		Pole[x - 1][y - 1 + ot] = ' '; Pole[x - 1][y + ot] = ' '; Pole[x - 1][y + 1 + ot] = ' ';
		Pole[x][y - 1 + ot] = ' '; Pole[x][y + ot] = ' '; Pole[x][y + 1 + ot] = ' ';
		Pole[x + 1][y - 1 + ot] = ' '; Pole[x + 1][y + ot] = ' '; Pole[x + 1][y + 1 + ot] = ' ';
		SetPos(y - 1 + ot, x + 1); cout << "   ";
		SetPos(y - 1 + ot, x); cout << "   ";
		SetPos(y - 1 + ot, x - 1); cout << "   ";
	}
	//функция отрисовки бомбы с проверкой на её стороны
	void bomb_omg(char** Pole, int x, int y) {
		Pole[x - 1][y - 1] = '7'; Pole[x - 1][y] = '8'; Pole[x - 1][y + 1] = '6';
		Pole[x][y - 1] = '9'; Pole[x][y] = '1'; Pole[x][y + 1] = 'E';
		Pole[x + 1][y - 1] = 'R'; Pole[x + 1][y] = '8'; Pole[x + 1][y + 1] = 'W';


		if (Pole[x][y - 2] != '0') {
			set_Left(true);
		}
		else { set_Left(false); }


		if (Pole[x][y + 2] != '0') {
			set_Right(true);
		}
		else { set_Right(false); }


		if (Pole[x - 2][y] != '0') {
			set_Up(true);
		}
		else { set_Up(false); }

		if (Pole[x + 2][y] != '0') {
			set_Down(true);
		}
		else { set_Down(false); }


		SetPos(y - 1, x - 1); cout << char(201) << char(207) << char(187);
		SetPos(y - 1, x); cout << char(199) << char(219) << char(182);
		SetPos(y - 1, x + 1);  cout << char(200) << char(207) << char(188);

	}

	//функция удаляющая все эллементы созданные бомбой
	void podtcithenie_bomb(char** Pole, int x, int y) {

		optimization_podtcithenie_bomb_Up_Down(Pole, x, y);
		if (get_Up() == true) {
			optimization_podtcithenie_bomb_Up_Down(Pole, x, y, -3);
		}
		if (get_Down() == true) {
			optimization_podtcithenie_bomb_Up_Down(Pole, x, y, 3);
		}
		if (get_Left() == true) {
			optimization_podtcithenie_bomb_Left_Right(Pole, x, y, -3);
		}
		if (get_Right() == true) {
			optimization_podtcithenie_bomb_Left_Right(Pole, x, y, +3);
		}
	}
	//функция рисущая взрыв бомбы с учетом их допустимых сторон
	void boom_bomb_omg(char** Pole, int x, int y) {
		Pole[x - 1][y - 1] = 'Y'; Pole[x - 1][y] = 'Y'; Pole[x - 1][y + 1] = 'Y';
		Pole[x][y - 1] = 'Y'; Pole[x][y] = 'Y'; Pole[x][y + 1] = 'Y';
		Pole[x + 1][y - 1] = 'Y'; Pole[x + 1][y] = 'Y'; Pole[x + 1][y + 1] = 'Y';
		SetPos(y - 1, x - 1); cout << char(177) << char(177) << char(177);
		SetPos(y - 1, x); cout << char(177) << char(177) << char(177);
		SetPos(y - 1, x + 1);  cout << char(177) << char(177) << char(177);

		if (get_Left() == true) {
			Pole[x - 1][y - 4] = 'T'; Pole[x - 1][y - 3] = 'T'; Pole[x - 1][y - 2] = 'T';
			Pole[x][y - 4] = 'T'; Pole[x][y - 3] = 'T'; Pole[x][y - 2] = 'Y';
			Pole[x + 1][y - 4] = 'T'; Pole[x + 1][y - 3] = 'T'; Pole[x + 1][y - 2] = 'T';

			SetPos(y - 4, x - 1); cout << char(176) << char(176) << char(176);
			SetPos(y - 4, x); cout << char(176) << char(176) << char(176);
			SetPos(y - 4, x + 1);  cout << char(176) << char(176) << char(176);
		}

		if (get_Right() == true) {
			Pole[x - 1][y + 2] = 'T'; Pole[x - 1][y + 3] = 'T'; Pole[x - 1][y + 4] = 'T';
			Pole[x][y + 2] = 'T'; Pole[x][y + 3] = 'T'; Pole[x][y + 4] = 'T';
			Pole[x + 1][y + 2] = 'T'; Pole[x + 1][y + 3] = 'T'; Pole[x + 1][y + 4] = 'T';
			SetPos(y + 2, x - 1); cout << char(176) << char(176) << char(176);
			SetPos(y + 2, x); cout << char(176) << char(176) << char(176);
			SetPos(y + 2, x + 1);  cout << char(176) << char(176) << char(176);
		}
		if (get_Up() == true) {
			Pole[x - 4][y - 1] = 'T'; Pole[x - 4][y] = 'T'; Pole[x - 4][y + 1] = 'T';
			Pole[x - 3][y - 1] = 'T'; Pole[x - 3][y] = 'T'; Pole[x - 3][y + 1] = 'T';
			Pole[x - 2][y - 1] = 'T'; Pole[x - 2][y] = 'T'; Pole[x - 2][y + 1] = 'T';
			SetPos(y - 1, x - 4); cout << char(176) << char(176) << char(176);
			SetPos(y - 1, x - 3); cout << char(176) << char(176) << char(176);
			SetPos(y - 1, x - 2);  cout << char(176) << char(176) << char(176);
		}

		if (get_Down() == true) {
			Pole[x + 2][y - 1] = 'T'; Pole[x + 2][y] = 'T'; Pole[x + 2][y + 1] = 'T';
			Pole[x + 3][y - 1] = 'T'; Pole[x + 3][y] = 'T'; Pole[x + 3][y + 1] = 'T';
			Pole[x + 4][y - 1] = 'T'; Pole[x + 4][y] = 'T'; Pole[x + 4][y + 1] = 'T';
			SetPos(y - 1, x + 2); cout << char(176) << char(176) << char(176);
			SetPos(y - 1, x + 3); cout << char(176) << char(176) << char(176);
			SetPos(y - 1, x + 4);  cout << char(176) << char(176) << char(176);
		}

	}

};

class Door_win :public coordinates {//класс дверь 
private:
	bool door;//проверка на появление двери на поле
public:
	Door_win() :door(false) {}//конструктор дверь

	//Акссесоры класса дверь
	bool get_door()const { return door; }
	bool set_door(bool d) { door = d; }
};


class Cgame {//класс комп. игра  - это основной класс который и несет в себе сому игру 
private:
	char** Pole;//поле  - несет в себе отрисовку поля и эллементы поля
	player host;//host - текщий игрок на уровне 
	Mob* mob;//mob  * все теккущие мобы пристутствующих на карте
	int kol_mob;// колличество мобов на поле
	Bomb boom;// бомба
	Door_win d;//дверь
	bool game;//проверка на завершение игры
	int Slep_moob;//замедление мобов
public:
	Cgame() :game(true), Slep_moob(13) {//конструктор класса ком.игра
		Pole = nullptr;
		Pole = new char* [27];
		for (int i = 0; i < 27; i++) {
			Pole[i] = new char[60];
		}
	}

	//Аксессоры класса ком.игра
	int get_Slep_mob()const { return Slep_moob; }
	void set_Slep_moob(int s) { Slep_moob = s; }

	//функция увеличение сна мобов на 1
	int Sleep_moob_Add(int add) { return Slep_moob += add; }

	//функция достающая из файла поле для игры 
	void igr_pole(const char* Mytxtfile) {
		ifstream ifile(Mytxtfile);
		host.set_x(22);
		host.set_y(4);
		int i = 0;
		int mm = 0;
		while (!ifile.eof()) {
			string str;
			getline(ifile, str);
			for (int j = 0; j < 60; j++) {
				Pole[i][j] = str[j];
				if (Pole[i][j] == 'e' || Pole[i][j] == 'm' || Pole[i][j] == 'h') {
					mm++;
				}
			}
			i++;
		}
		mob = new Mob[mm];
		int z = 0;
		for (int i = 0; i < 27; i++) {
			for (int j = 0; j < 60; j++) {
				if (Pole[i][j] == 'e' || Pole[i][j] == 'm' || Pole[i][j] == 'h') {
					mob[z].set_x(i);
					mob[z].set_y(j);
					z++;
				}
			}
		}
		kol_mob = mm;
		prorisovka_modelei();
	}

	//функция которая прячет выход
	void prorisovka_modelei() {
		int cnt = 0;
		for (int i = 0; i < 27; i++) {
			for (int j = 0; j < 60; j++) {
				if (Pole[i][j] == '#') { cnt++; }
			}
		}
		int random_door = rand() % cnt;
		cnt = 0;
		for (int i = 0; i < 27; i++) {
			for (int j = 0; j < 60; j++) {
				if (Pole[i][j] == 'p')
					host.Draw(Pole, i, j);
				if (Pole[i][j] == '#') {
					cnt++;
					if (random_door == cnt) {
						d.set_x(i);
						d.set_y(j);
					}
				}
			}
		}
	}

	//прорисовка поля
	void Show_Pole() {
		system("cls");
		for (int i = 0; i < 27; i++) {
			SetPos(0, i);
			for (int j = 0; j < 60; j++) {
				if (Pole[i][j] == '0') {
					cout << char(178);
					continue;
				}
				else if (Pole[i][j] == '1') {
					cout << char(219);
					continue;
				}
				else if (Pole[i][j] == '2') {
					cout << char(186);
					continue;
				}
				else if (Pole[i][j] == '3') {
					cout << char(244);
					continue;
				}
				else if (Pole[i][j] == '4') {
					cout << char(210);
					continue;
				}
				else if (Pole[i][j] == '5') {
					cout << char(197);
					continue;
				}
				else if (Pole[i][j] == '6') {
					cout << char(187);
					continue;
				}
				else if (Pole[i][j] == '7') {
					cout << char(201);
					continue;
				}
				else if (Pole[i][j] == '8') {
					cout << char(207);
					continue;
				}
				else if (Pole[i][j] == '9') {
					cout << char(202);
					continue;
				}
				else if (Pole[i][j] == 'Q') {
					cout << char(199);
					continue;
				}
				else if (Pole[i][j] == 'W') {
					cout << char(188);
					continue;
				}
				else if (Pole[i][j] == 'E') {
					cout << char(182);
					continue;
				}
				else if (Pole[i][j] == 'R') {
					cout << char(200);
					continue;
				}

				cout << Pole[i][j];
			}
		}
	}

	//функиция игры
	void GGO() {
		int key;
		srand(time(0));
		bool pl_hp = true;
		while (true) {
			host.Proverka(Pole, host.get_x(), host.get_y());
			if (_kbhit()) {
				key = _getch();
				if (key == CURSOR1 || key == CURSOR2) {
					key = _getch();
				}
				while (_kbhit()) _getch();
				if (UP == key && host.get_Up() == true) {
					host.podtcithenie(Pole, host.get_x(), host.get_y());
					host.minus_x_player();
					host.Draw(Pole, host.get_x(), host.get_y());
					host.risovayie_player(host.get_x(), host.get_y());
				}

				else if (DOWN == key && host.get_Down() == true) {
					host.podtcithenie(Pole, host.get_x(), host.get_y());
					host.plus_x_player();
					host.Draw(Pole, host.get_x(), host.get_y());
					host.risovayie_player(host.get_x(), host.get_y());
				}

				else if (LEFT == key && host.get_Left() == true) {
					host.podtcithenie(Pole, host.get_x(), host.get_y());
					host.minus_y_player();
					host.Draw(Pole, host.get_x(), host.get_y());
					host.risovayie_player(host.get_x(), host.get_y());
				}
				else if (RIGHT == key && host.get_Right() == true) {
					host.podtcithenie(Pole, host.get_x(), host.get_y());
					host.plus_y_player();
					host.Draw(Pole, host.get_x(), host.get_y());
					host.risovayie_player(host.get_x(), host.get_y());
				}
				else if (ENTER == key) {
					if (boom.get_bomb() == false) {
						boom.set_x(host.get_x());
						boom.set_y(host.get_y());
						boom.bomb_omg(Pole, boom.get_x(), boom.get_y());
						boom.set_bomb(true);
						boom.set_vz(120000);
					}
				}
				else if (ESC == key) {
					system("cls");
					return;
				}
			}
			if (boom.get_vz() == 30000) {
				boom.boom_bomb_omg(Pole, boom.get_x(), boom.get_y());
			}
			else if (boom.get_vz() == 0 && boom.get_bomb() == true) {
				boom.podtcithenie_bomb(Pole, boom.get_x(), boom.get_y());
				boom.set_bomb(false);
			}
			if (boom.get_vz() != 0 && boom.get_bomb() == true) {
				boom.vz_minus_minus();
			}
			int size = 4;
			int moob;
			int mob_rand;


			if (Pole[d.get_x()][d.get_door()] == ' ' && d.get_door() == false) {
				system("cls");
				cout << "You win!";
				cin.get();
				return;
			}
			if (Sleep_moob_Add(-1) == 0) {
				set_Slep_moob(15000);


				for (int i = 0; i < kol_mob; i++) {
					mob[i].Proverka(Pole, mob[i].get_x(), mob[i].get_y());
					int mob_rand = rand() % 4 + 1;
					if (mob_rand == 4 && mob[i].get_Down() == true) {
						mob[i].podtcithenie_mob(Pole, mob[i].get_x(), mob[i].get_y());
						mob[i].Draw_e(Pole, mob[i].get_x(), mob[i].get_y(), 3);
					}
					if (mob_rand == 3 && mob[i].get_Up() == true) {
						mob[i].podtcithenie_mob(Pole, mob[i].get_x(), mob[i].get_y());
						mob[i].Draw_e(Pole, mob[i].get_x(), mob[i].get_y(), -3);
					}
					if (mob_rand == 2 && mob[i].get_Left() == true) {
						mob[i].podtcithenie_mob(Pole, mob[i].get_x(), mob[i].get_y());
						mob[i].Draw_e(Pole, mob[i].get_x(), mob[i].get_y(), 0, -3);
					}
					if (mob_rand == 1 && mob[i].get_Right() == true) {
						mob[i].podtcithenie_mob(Pole, mob[i].get_x(), mob[i].get_y());
						mob[i].Draw_e(Pole, mob[i].get_x(), mob[i].get_y(), 0, 3);
					}
					if ((mob[i].IsIntersept(host)) == true) {
						system("cls");
						cout << "You Lose!!";
						return;
					}
				}

			}
			if (Pole[host.get_x()][host.get_y()] == 'T' || Pole[host.get_x()][host.get_y()] == 'Y') {
				system("cls");
				cout << "You Lose!!";
				return;
			}

		}
	}

};

//функция меню
void Menu() {
	const char* lvl = "lvl.txt";
	int key;
	int active = mmenu::Start;
	bool redrawMenu = true;
	while (true) {

		if (_kbhit()) {
			key = _getch();

			if (key == UP) {
				redrawMenu = true;
				switch (active) {
				case mmenu::Start: active = mmenu::Exit; break;
				case mmenu::Info: active = mmenu::Start; break;
				case mmenu::Exit: active = mmenu::Info; break;
				}
			}
			else if (key == DOWN) {
				redrawMenu = true;
				switch (active) {
				case mmenu::Start: active = mmenu::Info; break;
				case mmenu::Info: active = mmenu::Exit; break;
				case mmenu::Exit: active = mmenu::Start; break;
				}
			}
			else if (key == ENTER) {
				redrawMenu = true;
				switch (active) {
				case mmenu::Start: {
					active = vlvl::lvl1;
					system("cls");
					while (true) {
						if (_kbhit()) {
							key = _getch();
							if (key == UP) {
								redrawMenu = true;
								switch (active) {
								case vlvl::lvl1:active = vlvl::lvl5; break;
								case vlvl::lvl2:active = vlvl::lvl1; break;
								case vlvl::lvl3:active = vlvl::lvl2; break;
								case vlvl::lvl4:active = vlvl::lvl3; break;
								case vlvl::lvl5:active = vlvl::lvl4; break;
								}
							}
							else if (key == DOWN) {
								redrawMenu = true;
								switch (active) {
								case vlvl::lvl1:active = vlvl::lvl2; break;
								case vlvl::lvl2:active = vlvl::lvl3; break;
								case vlvl::lvl3:active = vlvl::lvl4; break;
								case vlvl::lvl4:active = vlvl::lvl5; break;
								case vlvl::lvl5:active = vlvl::lvl1; break;
								}

							}
							else if (key == ENTER) {

								switch (active) {
								case vlvl::lvl1:lvl = "lvl1.txt"; break;
								case vlvl::lvl2:lvl = "lvl2.txt"; break;
								case vlvl::lvl3:lvl = "lvl3.txt"; break;
								case vlvl::lvl4:lvl = "lvl4.txt"; break;
								case vlvl::lvl5:lvl = "lvl5.txt"; break;
								}
								Cgame A;
								A.igr_pole(lvl);
								A.Show_Pole();
								A.GGO();
							}
							else if (key == ESC) {
								break; break;
							}
						}
						if (redrawMenu) {
							redrawMenu = false;
							SetPos(20, 4);
							active == vlvl::lvl1 ? cout << "->lvl1" : cout << "  lvl1";
							SetPos(20, 6);
							active == vlvl::lvl2 ? cout << "->lvl2" : cout << "  lvl2";
							SetPos(20, 8);
							active == vlvl::lvl3 ? cout << "->lvl3" : cout << "  lvl3";
							SetPos(20, 10);
							active == vlvl::lvl4 ? cout << "->lvl4" : cout << "  lvl4";
							SetPos(20, 12);
							active == vlvl::lvl5 ? cout << "->lvl5" : cout << "  lvl5";
						}


					}
					break;
				}//Start
				case mmenu::Info: {break; }//добавить инфу
				case mmenu::Exit: {exit(0); }
				}

			}
		}
		else {
			Sleep(1);
		}
		if (redrawMenu) {
			system("cls");
			redrawMenu = false;
			SetPos(20, 8);
			active == mmenu::Start ? cout << "->Start" : cout << "  Start";
			SetPos(20, 10);
			active == mmenu::Info ? cout << "->Info" : cout << "  Info";
			SetPos(20, 12);
			active == mmenu::Exit ? cout << "->Exit" : cout << "  Exit";
		}
	}
}


int main() {
	srand(time(0));
	Menu();
	cin.get();
}